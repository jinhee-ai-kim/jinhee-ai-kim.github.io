# -*- coding: utf-8 -*-
import pygame
import random
import sys
import asyncio

SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (34, 139, 34)
RED = (220, 20, 60)
YELLOW = (255, 220, 0)
PURPLE = (150, 0, 200)
WARNING_DURATION = 45
BOOST_DURATION = 120


class Player(pygame.sprite.Sprite):
    def __init__(self, pacman_img, pacman_close_img, red_pacman_img):
        super().__init__()
        self.pacman_img = pacman_img
        self.pacman_close_img = pacman_close_img
        self.red_pacman_img = red_pacman_img
        self.width = 100
        self.height = 100
        self.rect = pygame.Rect(0, 0, self.width, self.height)
        self.rect.centerx = SCREEN_WIDTH // 2
        self.rect.bottom = SCREEN_HEIGHT - 10
        self.speed = 7
        self.hurt_timer = 0
        self.eat_timer = 0

    def update(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and self.rect.left > 0:
            self.rect.x -= self.speed
        if keys[pygame.K_RIGHT] and self.rect.right < SCREEN_WIDTH:
            self.rect.x += self.speed
        if self.hurt_timer > 0:
            self.hurt_timer -= 1
        if self.eat_timer > 0:
            self.eat_timer -= 1

    def draw(self, surface):
        if self.hurt_timer > 0:
            img = self.red_pacman_img
        elif self.eat_timer > 0:
            img = self.pacman_close_img
        else:
            img = self.pacman_img
        surface.blit(img, self.rect)


class Food(pygame.sprite.Sprite):
    def __init__(self, food_type, images, start_y=None):
        super().__init__()
        self.food_type = food_type
        self.width = 48
        self.height = 48

        if food_type == 'taco':
            self.image = images['taco'].copy()
            self.points = 10
        elif food_type == 'milkshake':
            self.height = 66
            self.image = images['milkshake'].copy()
            self.points = 20
        elif food_type == 'spider':
            self.image = images['spider'].copy()
            self.points = 0
        else:
            self.image = images['snake'].copy()
            self.points = 0

        self.rect = self.image.get_rect()
        self.rect.x = random.randint(0, SCREEN_WIDTH - self.width)
        self.rect.y = start_y if start_y is not None else random.randint(-100, -40)
        self.speed = random.randint(2, 5)

    def update(self):
        self.rect.y += self.speed
        if self.rect.top > SCREEN_HEIGHT:
            self.kill()

    def draw(self, surface):
        surface.blit(self.image, self.rect)


def draw_lives(surface, bad_count, font_small):
    lives_text = font_small.render("Lives:", True, BLACK)
    surface.blit(lives_text, (SCREEN_WIDTH - 255, 15))
    for i in range(5):
        color = RED if i >= (5 - bad_count) else (200, 200, 200)
        cx = SCREEN_WIDTH - 195 + i * 38
        cy = 32
        pygame.draw.circle(surface, color, (cx, cy), 12)
        pygame.draw.circle(surface, BLACK, (cx, cy), 12, 2)


def draw_boost_flash(surface, timer, font_large):
    alpha = int(180 * abs((timer % 20) - 10) / 10)
    flash = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
    border = 22
    color = (255, 220, 0, alpha)
    pygame.draw.rect(flash, color, (0, 0, SCREEN_WIDTH, border))
    pygame.draw.rect(flash, color, (0, SCREEN_HEIGHT - border, SCREEN_WIDTH, border))
    pygame.draw.rect(flash, color, (0, 0, border, SCREEN_HEIGHT))
    pygame.draw.rect(flash, color, (SCREEN_WIDTH - border, 0, border, SCREEN_HEIGHT))
    surface.blit(flash, (0, 0))
    text_color = YELLOW if (timer // 6) % 2 == 0 else WHITE
    boost_surf = font_large.render("BOOST!", True, text_color)
    surface.blit(boost_surf, (SCREEN_WIDTH // 2 - boost_surf.get_width() // 2, SCREEN_HEIGHT // 2 - 40))


def draw_warning_flash(surface, timer, font_large):
    alpha = int(200 * (timer / WARNING_DURATION))
    flash = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
    border = 18
    pygame.draw.rect(flash, (220, 20, 60, alpha), (0, 0, SCREEN_WIDTH, border))
    pygame.draw.rect(flash, (220, 20, 60, alpha), (0, SCREEN_HEIGHT - border, SCREEN_WIDTH, border))
    pygame.draw.rect(flash, (220, 20, 60, alpha), (0, 0, border, SCREEN_HEIGHT))
    pygame.draw.rect(flash, (220, 20, 60, alpha), (SCREEN_WIDTH - border, 0, border, SCREEN_HEIGHT))
    surface.blit(flash, (0, 0))
    if (timer // 6) % 2 == 0:
        warn_surf = font_large.render("DANGER!", True, RED)
        surface.blit(warn_surf, (SCREEN_WIDTH // 2 - warn_surf.get_width() // 2, SCREEN_HEIGHT // 2 - 40))


def draw_win_screen(surface, seconds, score, font_large, font_mid, font_small):
    overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 160))
    surface.blit(overlay, (0, 0))
    win_text = font_large.render("YOU WIN!", True, YELLOW)
    surface.blit(win_text, (SCREEN_WIDTH // 2 - win_text.get_width() // 2, 180))
    time_text = font_mid.render(f"Clear Time: {seconds}s", True, WHITE)
    surface.blit(time_text, (SCREEN_WIDTH // 2 - time_text.get_width() // 2, 270))
    score_text = font_mid.render(f"Final Score: {score}", True, WHITE)
    surface.blit(score_text, (SCREEN_WIDTH // 2 - score_text.get_width() // 2, 330))
    retry_text = font_small.render("ESC: Quit", True, (180, 180, 180))
    surface.blit(retry_text, (SCREEN_WIDTH // 2 - retry_text.get_width() // 2, 420))


def draw_lose_screen(surface, score, font_large, font_mid, font_small):
    overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 160))
    surface.blit(overlay, (0, 0))
    lose_text = font_large.render("GAME OVER", True, RED)
    surface.blit(lose_text, (SCREEN_WIDTH // 2 - lose_text.get_width() // 2, 220))
    score_text = font_mid.render(f"Score: {score}", True, WHITE)
    surface.blit(score_text, (SCREEN_WIDTH // 2 - score_text.get_width() // 2, 310))
    retry_text = font_small.render("ESC: Quit", True, (180, 180, 180))
    surface.blit(retry_text, (SCREEN_WIDTH // 2 - retry_text.get_width() // 2, 400))


async def main():
    pygame.init()

    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Taco Eating Game")

    clock = pygame.time.Clock()
    FPS = 60
    font_large = pygame.font.Font(None, 60)
    font_mid = pygame.font.Font(None, 48)
    font_small = pygame.font.Font(None, 36)

    await asyncio.sleep(0)  # yield before image loading

    bg_image = pygame.image.load("assets/img/tacoman/bg_img.png")
    bg_image = pygame.transform.scale(bg_image, (SCREEN_WIDTH, SCREEN_HEIGHT))

    images = {
        'taco':      pygame.transform.scale(pygame.image.load("assets/img/tacoman/taco.png"), (48, 48)),
        'milkshake': pygame.transform.scale(pygame.image.load("assets/img/tacoman/milkshake.png"), (48, 66)),
        'spider':    pygame.transform.scale(pygame.image.load("assets/img/tacoman/spider.png"), (48, 48)),
        'snake':     pygame.transform.scale(pygame.image.load("assets/img/tacoman/snake.png"), (48, 48)),
    }
    pacman_img       = pygame.transform.scale(pygame.image.load("assets/img/tacoman/pacman.png"), (100, 100))
    pacman_close_img = pygame.transform.scale(pygame.image.load("assets/img/tacoman/pacman_close.png"), (100, 100))
    red_pacman_img   = pygame.transform.scale(pygame.image.load("assets/img/tacoman/red_pacman.png"), (100, 100))

    score = 0
    bad_count = 0
    boost_active = False
    boost_timer = 0
    boost_spawn_count = 0
    warning_timer = 0
    game_state = 'playing'
    elapsed_seconds = 0
    spawn_timer = 0
    spawn_interval = 30
    start_ticks = pygame.time.get_ticks()

    player_group = pygame.sprite.Group()
    food_group = pygame.sprite.Group()
    player = Player(pacman_img, pacman_close_img, red_pacman_img)
    player_group.add(player)

    running = True
    while running:
        clock.tick(FPS)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False

        if game_state == 'playing':
            spawn_timer += 1
            if spawn_timer >= spawn_interval:
                food_types = ['taco', 'spider', 'snake', 'milkshake']
                food_type = random.choices(food_types, weights=[6, 2, 2, 1])[0]
                food_group.add(Food(food_type, images))
                spawn_timer = 0

            if boost_active:
                boost_timer -= 1
                if boost_spawn_count > 0 and spawn_timer % 4 == 0:
                    for _ in range(2):
                        food_group.add(Food('taco', images, start_y=random.randint(-80, -20)))
                    boost_spawn_count -= 1
                if boost_timer <= 0:
                    boost_active = False
                    boost_spawn_count = 0

            if warning_timer > 0:
                warning_timer -= 1

            player_group.update()
            food_group.update()

            for food in list(food_group):
                food_hitbox = food.rect.inflate(-20, -20)
                if player.rect.inflate(-20, -20).colliderect(food_hitbox):
                    if food.food_type == 'taco':
                        score += food.points
                        player.eat_timer = 12
                    elif food.food_type == 'milkshake':
                        score += food.points
                        player.eat_timer = 12
                        boost_active = True
                        boost_timer = BOOST_DURATION
                        boost_spawn_count = 8
                    elif food.food_type in ('spider', 'snake'):
                        bad_count += 1
                        warning_timer = WARNING_DURATION
                        player.hurt_timer = 60
                    food.kill()

            if score >= 1000:
                game_state = 'win'
                elapsed_seconds = (pygame.time.get_ticks() - start_ticks) // 1000
            elif bad_count >= 5:
                game_state = 'lose'

        screen.blit(bg_image, (0, 0))

        if game_state == 'playing':
            player.draw(screen)
            for food in food_group:
                food.draw(screen)
            score_text = font_large.render(f"Score: {score}", True, BLACK)
            screen.blit(score_text, (20, 15))
            draw_lives(screen, bad_count, font_small)
            if warning_timer > 0:
                draw_warning_flash(screen, warning_timer, font_large)
            if boost_active:
                draw_boost_flash(screen, boost_timer, font_large)

        elif game_state == 'win':
            player.draw(screen)
            for food in food_group:
                food.draw(screen)
            draw_win_screen(screen, elapsed_seconds, score, font_large, font_mid, font_small)

        elif game_state == 'lose':
            player.draw(screen)
            for food in food_group:
                food.draw(screen)
            draw_lose_screen(screen, score, font_large, font_mid, font_small)

        pygame.display.flip()
        await asyncio.sleep(0)

    pygame.quit()


asyncio.run(main())
